#pragma once
#include <string>

class DotNetObjectFactoryMixed
{
public:
    IDispatch* GetNetObject(BSTR filePath, BSTR className);
	void Quit();
};
